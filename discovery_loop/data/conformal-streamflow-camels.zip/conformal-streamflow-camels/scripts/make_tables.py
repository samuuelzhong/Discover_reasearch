#!/usr/bin/env python3
"""Build every table and every number quoted in the paper from the result files.

Usage:  python scripts/make_tables.py [RESULTS_DIR] [OUT_DIR]
        defaults: results  outputs/tables

Inputs (RESULTS_DIR):
    v6_revision_v2_results.json, v7_revision_v2_results.json,
    v8_revision_v2_results.json         notebook 04 (v6 = F1, v7 = F2, v8 = F3)
    main_table_all_forecasters.csv      scripts/collect_main_table.py
    aci_diagnostics.csv                 notebook 05
    sensitivity_results.json            notebook 06
    extra_figures.json                  notebook 07
    nse_per_basin_all.csv               notebook 08
    skill_v8.csv                        notebook 03
    training_summary.json               quantities printed by notebooks 01-03

Outputs (OUT_DIR):
    tab_*.tex       one booktabs table body per table of the paper
    numbers.tex     one LaTeX macro per number quoted in the text (\\rv{key});
                    an unknown key stops compilation
    numbers.csv     the same key/value list

Consistency checks between the result files are asserted throughout.
"""
import json
import re
import sys
from pathlib import Path

import pandas as pd

RES = Path(sys.argv[1] if len(sys.argv) > 1 else "results")
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "outputs/tables")
OUT.mkdir(parents=True, exist_ok=True)

FCS = ["v6", "v7", "v8"]
LEADS = [1, 3, 7]
FC_LABEL = {"v6": "F1", "v7": "F2", "v8": "F3"}   # names used in the paper
TARGET = 90.0

# ---------------------------------------------------------------- load
J = {fc: json.loads((RES / f"{fc}_revision_v2_results.json").read_text()) for fc in FCS}
MAIN = pd.read_csv(RES / "main_table_all_forecasters.csv")
ACI = pd.read_csv(RES / "aci_diagnostics.csv")
SENS = json.loads((RES / "sensitivity_results.json").read_text())
S = {k: pd.DataFrame(v) for k, v in SENS.items()}

# ---------------------------------------------------------------- integrity checks
assert set(MAIN.forecaster) == set(FCS), MAIN.forecaster.unique()
assert len(MAIN) == 8 * 3 * 3, len(MAIN)
for fc in FCS:   # CSV and JSON must agree
    b1 = pd.DataFrame(J[fc]["B1_main"])
    m = MAIN[MAIN.forecaster == fc].merge(b1, on=["lead", "method"], suffixes=("", "_j"))
    assert len(m) == 24, (fc, len(m))
    for c in ["coverage", "peak", "width_mean", "winkler"]:
        assert (m[c] - m[c + "_j"]).abs().max() < 1e-6, (fc, c)
RULE = "ACI delay-scaled (gamma=0.005/L)"
assert RULE in set(ACI.method), ACI.method.unique()
print("integrity checks passed")

# ---------------------------------------------------------------- number registry
NUM = {}


def put(key, value, fmt="{:.1f}"):
    assert key not in NUM, f"duplicate key {key}"
    NUM[key] = fmt.format(value) if not isinstance(value, str) else value


def f1(x):
    return f"{x:.1f}"


def f2(x):
    return f"{x:.2f}"


def ci(c, f=f2):
    return f"[{f(c[0])}, {f(c[1])}]"


# ---------------------------------------------------------------- one basin set for all skill numbers
# nse_per_basin_all.csv (notebook 08) holds the per-basin NSE of every forecaster and of
# persistence at every lead time, computed with one code path. When it is present, every skill number
# (Table 2, Table A1, Figure 5 and the text) uses all basins with a defined NSE; otherwise Table A1 falls
# back to B7_nse (basins with at least 100 test forecasts) and Table 2 to skill_v8.csv (all basins).
NSEF = RES / "nse_per_basin_all.csv"
SK_ALL = None
if NSEF.exists():
    _N = pd.read_csv(NSEF)
    _old = {fc: dict(J[fc]["B7_nse"]) for fc in FCS}
    for fc in FCS:
        d = _N[(_N.forecaster == fc) & (_N.lead == 1)].nse_model.dropna()
        J[fc]["B7_nse"] = dict(median=d.median(), q25=d.quantile(.25), q75=d.quantile(.75),
                               frac_above_0p5=(d > 0.5).mean())
        assert abs(d.median() - _old[fc]["median"]) < 0.01, (fc, "median moved by more than 0.01")
    _nb = {(fc, L): _N[(_N.forecaster == fc) & (_N.lead == L)].nse_model.notna().sum() for fc in FCS for L in LEADS}
    assert len(set(_nb.values())) == 1, ("basin set differs between forecasters or leads", _nb)
    NB = list(_nb.values())[0]
    rows_sk = []
    for L in LEADS:
        d = _N[(_N.forecaster == "v8") & (_N.lead == L)].dropna(subset=["nse_model"])
        rows_sk.append(dict(lead=L, nse_model_median=d.nse_model.median(), nse_model_q25=d.nse_model.quantile(.25),
                            nse_model_q75=d.nse_model.quantile(.75), pct_model_gt05=100 * (d.nse_model > 0.5).mean(),
                            nse_persist_median=d.nse_persist.dropna().median(),
                            pct_basins_model_beats_persist=100 * (d.nse_model > d.nse_persist).mean()))
    SK_ALL = pd.DataFrame(rows_sk).set_index("lead")
    put("skill.A1.basins", f"over all {NB} basins with a defined NSE, the same basins as in Table~\\ref{{tab:skill}}")
    put("skill.T2.basins", f"over all {NB} basins with a defined NSE")
else:
    put("skill.A1.basins", "over basins with at least 100 test forecasts; the F3 values can therefore differ "
                           "in the second decimal from Table~\\ref{tab:skill}")
    put("skill.T2.basins", "over all basins with a defined NSE")

# ---------------------------------------------------------------- Table 1: forecaster skill
rows = []
for fc in FCS:
    n = J[fc]["B7_nse"]
    rows.append((FC_LABEL[fc], f2(n["median"]), f"{f2(n['q25'])}--{f2(n['q75'])}",
                 f"{100 * n['frac_above_0p5']:.0f}"))
    put(f"{fc}.nse.median", n["median"], "{:.2f}")
    put(f"{fc}.nse.q25", n["q25"], "{:.2f}")
    put(f"{fc}.nse.q75", n["q75"], "{:.2f}")
    put(f"{fc}.nse.pctabove05", 100 * n["frac_above_0p5"], "{:.0f}")


MINUS = re.compile(r"(?<![\w$\-])-(?=\d)")   # typographic minus for negative numbers


def write(name, header, rows, colspec, note=None):
    lines = [f"\\begin{{tabular}}{{{colspec}}}", "\\toprule", header + " \\\\", "\\midrule"]
    for r in rows:
        lines.append(r if isinstance(r, str) else " & ".join(r) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    lines = [MINUS.sub(r"\\ensuremath{-}", ln) for ln in lines]
    if note:
        lines.append(f"% {note}")
    (OUT / f"{name}.tex").write_text("\n".join(lines) + "\n")


write("tab_skill",
      "Forecaster & Median NSE & IQR & Basins with NSE $>0.5$ (\\%)",
      rows, "lccc", "lead-1 test-period NSE per basin; source B7_nse")

# F3 skill by lead against persistence (skill_v8.csv, notebook 03)
SK = pd.read_csv(RES / "skill_v8.csv").set_index("lead")
if SK_ALL is not None:   # same values as skill_v8.csv up to rounding; checked by notebook 08
    SK = SK_ALL
# B7_nse (671 basins with finite NSE) and skill_v8.csv (672 basins) must agree when rounded
assert f2(SK.loc[1, "nse_model_median"]) == f2(J["v8"]["B7_nse"]["median"])
rows = []
for lead in LEADS:
    r = SK.loc[lead]
    rows.append((str(lead), f2(r.nse_model_median), f"{f2(r.nse_model_q25)}--{f2(r.nse_model_q75)}",
                 f"{r.pct_model_gt05:.0f}", f2(r.nse_persist_median),
                 f"{r.pct_basins_model_beats_persist:.0f}"))
    k = f"v8.skill.L{lead}"
    put(k + ".nse", r.nse_model_median, "{:.2f}")
    put(k + ".persist", r.nse_persist_median, "{:.2f}")
    put(k + ".pctgt05", r.pct_model_gt05, "{:.0f}")
    put(k + ".beatspersist", r.pct_basins_model_beats_persist, "{:.0f}")
write("tab_skill_v8_leads",
      "Lead (d) & Median NSE & IQR & NSE $>0.5$ (\\%) & Persistence median NSE & Basins beating persistence (\\%)",
      rows, "cccccc", "F3 test period; source skill_v8.csv")

# ---------------------------------------------------------------- Table 2..4: main results per forecaster
METHOD_ORDER = ["Raw band", "Gaussian", "MC-dropout (epistemic)", "MC-dropout + aleatoric",
                "Split conformal", "CQR", "Mondrian CQR", "ACI (causal, per-basin)"]
METHOD_TEX = {"ACI (causal, per-basin)": "ACI (per basin)"}
CONFORMAL = {"Split conformal", "CQR", "Mondrian CQR", "ACI (causal, per-basin)"}


def main_table(fc):
    d = MAIN[MAIN.forecaster == fc]
    rows = []
    for li, lead in enumerate(LEADS):
        dl = d[d.lead == lead].set_index("method").loc[METHOD_ORDER]
        best_w = dl.loc[list(CONFORMAL), "winkler"].min()
        best_p = dl.loc[list(CONFORMAL), "peak"].max()
        if li:
            rows.append("\\midrule")
        for i, (meth, r) in enumerate(dl.iterrows()):
            w = f2(r.winkler)
            p = f1(r.peak)
            # bold every conformal method that ties the best value at the printed precision
            if meth in CONFORMAL and f2(r.winkler) == f2(best_w):
                w = f"\\textbf{{{w}}}"
            if meth in CONFORMAL and f1(r.peak) == f1(best_p):
                p = f"\\textbf{{{p}}}"
            lead_cell = f"\\multirow{{8}}{{*}}{{{lead}}}" if i == 0 else ""
            rows.append((lead_cell, METHOD_TEX.get(meth, meth), f1(r.coverage), p,
                         f2(r.width_mean), f2(r.width_median), w))
            key = f"{fc}.L{lead}.{meth}"
            put(key + ".cov", r.coverage)
            put(key + ".peak", r.peak)
            put(key + ".wmean", r.width_mean, "{:.2f}")
            put(key + ".wmed", r.width_median, "{:.2f}")
            put(key + ".winkler", r.winkler, "{:.2f}")
    write(f"tab_main_{fc}",
          "Lead (d) & Method & Coverage (\\%) & Q95 peak cov.\\ (\\%) & Mean width & Median width & Winkler",
          rows, "llccccc",
          "bold: best Winkler (lowest) and best peak coverage among conformal methods per lead")


for fc in FCS:
    main_table(fc)

# ---------------------------------------------------------------- Table 5: cross-forecaster summary
rows = []
SUMM = ["Raw band", "Split conformal", "CQR", "Mondrian CQR", "ACI (causal, per-basin)"]
for li, lead in enumerate(LEADS):
    if li:
        rows.append("\\midrule")
    for i, meth in enumerate(SUMM):
        cells = []
        for fc in FCS:
            r = MAIN[(MAIN.forecaster == fc) & (MAIN.lead == lead) & (MAIN.method == meth)].iloc[0]
            cells += [f1(r.coverage), f1(r.peak), f2(r.winkler)]
        lead_cell = f"\\multirow{{{len(SUMM)}}}{{*}}{{{lead}}}" if i == 0 else ""
        rows.append((lead_cell, METHOD_TEX.get(meth, meth), *cells))
hdr = ("& & \\multicolumn{3}{c}{F1} & \\multicolumn{3}{c}{F2} & \\multicolumn{3}{c}{F3} \\\\\n"
       "\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\\cmidrule(lr){9-11}\n"
       "Lead & Method & Cov. & Peak & Wink. & Cov. & Peak & Wink. & Cov. & Peak & Wink.")
write("tab_cross_forecaster", hdr, rows, "ll" + "ccc" * 3)

# ---------------------------------------------------------------- Table 6: bootstrap contrasts
CONTR = [("mondrian_minus_cqr_peak", "Mondrian $-$ CQR, peak coverage"),
         ("aci_minus_mondrian_peak", "ACI $-$ Mondrian, peak coverage"),
         ("cqr_minus_split_coverage", "CQR $-$ split, coverage")]
rows = []
for ci_i, (k, lab) in enumerate(CONTR):
    if ci_i:
        rows.append("\\midrule")
    for i, lead in enumerate(LEADS):
        cells = []
        for fc in FCS:
            b = J[fc]["B4_bootstrap_cis"][f"{k}_lead{lead}"]
            cells.append(f"{b['delta']:+.2f} {ci(b['ci'])}")
            put(f"{fc}.L{lead}.{k}", b["delta"], "{:+.2f}")
            put(f"{fc}.L{lead}.{k}.ci", ci(b["ci"]))
        rows.append((f"\\multirow{{3}}{{=}}{{{lab}}}" if i == 0 else "", str(lead), *cells))
write("tab_bootstrap",
      "Contrast (points) & Lead & F1 & F2 & F3", rows, "p{4.2cm}cccc",
      "basin-bootstrap 95% CI; source B4_bootstrap_cis")

# ---------------------------------------------------------------- Table 7: ACI windup
ACI_ROWS = [("ACI", 0.005, "Fixed $\\gamma=0.005$"),
            (RULE, None, "Delay-scaled $\\gamma=0.005/L$"),
            ("Mondrian CQR", None, "Mondrian CQR")]
rows = []
for fi, fc in enumerate(FCS):
    if fi:
        rows.append("\\midrule")
    first = True
    for lead in LEADS:
        for meth, g, lab in ACI_ROWS:
            sel = (ACI.forecaster == fc) & (ACI.lead == lead) & (ACI.method == meth)
            if g is not None:
                sel &= (ACI.gamma - g).abs() < 1e-9
            d = ACI[sel]
            if d.empty:
                continue
            assert len(d) == 1, (fc, lead, meth, len(d))
            r = d.iloc[0]
            rows.append((f"\\multirow{{9}}{{*}}{{{FC_LABEL[fc]}}}" if first else "",
                         str(lead), lab, f1(r.coverage), f1(r.peak), f2(r.width_mean),
                         f2(r.width_p99), f1(r.width_max), f2(r.pct_width_gt5), f2(r.winkler)))
            first = False
            tag = {"ACI": "aci_fixed", RULE: "aci_rule", "Mondrian CQR": "mondrian"}[meth]
            k = f"{fc}.L{lead}.{tag}"
            for c, fmt in [("coverage", "{:.1f}"), ("peak", "{:.1f}"), ("width_mean", "{:.2f}"),
                           ("width_p99", "{:.2f}"), ("width_max", "{:.1f}"),
                           ("pct_width_gt5", "{:.2f}"), ("winkler", "{:.2f}")]:
                put(f"{k}.{c}", r[c], fmt)
            if meth != "Mondrian CQR":
                put(f"{k}.min_alpha", r.min_alpha_internal, "{:.3f}")
                put(f"{k}.pct_alpha_floor", r.pct_alpha_at_floor, "{:.2f}")
write("tab_aci_windup",
      "Fc. & Lead & Variant & Cov. & Peak & Mean w. & p99 w. & Max w. & \\% w.$>5$ & Winkler",
      rows, "cclccccccc", "source aci_diagnostics.csv")

# gamma grid (supplementary)
rows = []
g = ACI[ACI.method == "ACI"].sort_values(["forecaster", "lead", "gamma"])
prev = None
for _, r in g.iterrows():
    if prev is not None and r.forecaster != prev:
        rows.append("\\midrule")
    a = round(r.min_alpha_internal, 4) + 0.0          # +0.0 removes a negative zero
    rows.append((FC_LABEL[r.forecaster] if r.forecaster != prev else "", str(r.lead), f"{r.gamma:g}",
                 f1(r.coverage), f2(r.width_mean), f1(r.width_max), f2(r.winkler), f"{a:.4f}"))
    prev = r.forecaster
write("tab_aci_gamma_grid",
      "Fc. & Lead & $\\gamma$ & Cov. & Mean w. & Max w. & Winkler & min $\\alpha_t$",
      rows, "ccrccccc")

# ---------------------------------------------------------------- Table 8: calibration granularity
rows = []
for fc in FCS:
    for mode, lab in [("pooled", "Pooled"), ("per_basin", "Per basin")]:
        q = J[fc]["B6_granularity"][mode]
        rows.append((FC_LABEL[fc] if mode == "pooled" else "", lab, f1(q["pooled_coverage"]),
                     f1(q["basin_median"]), f"{f1(q['basin_iqr'][0])}--{f1(q['basin_iqr'][1])}",
                     f"{100 * q['frac_within_2pts']:.0f}", f2(q["mean_width"])))
        k = f"{fc}.gran.{mode}"
        put(k + ".cov", q["pooled_coverage"])
        put(k + ".basinmed", q["basin_median"])
        put(k + ".within2", 100 * q["frac_within_2pts"], "{:.0f}")
        put(k + ".width", q["mean_width"], "{:.2f}")
    if fc != FCS[-1]:
        rows.append("\\midrule")
write("tab_granularity",
      "Fc. & Calibration & Overall cov. & Basin median & Basin IQR & Basins within $\\pm2$ (\\%) & Mean width",
      rows, "llccccc", "CQR, lead 1; source B6_granularity")

# drift
for fc in FCS:
    for meth, v in J[fc]["B6_drift"].items():
        k = f"{fc}.drift.{meth}"
        put(k, v["slope"], "{:+.2f}")
        put(k + ".ci", ci(v["ci"]))

# ---------------------------------------------------------------- Sensitivity S1..S5
SM = ["Split conformal", "CQR", "Mondrian CQR", "ACI (delay-scaled)"]

# S1: peak threshold, lead 1, test-period thresholds; calibration-period in supplement
s1 = S["S1_peak_threshold"]
for src in ["test", "calibration"]:
    rows = []
    for fc in FCS:
        for i, m in enumerate(SM):
            cells = []
            for q in [0.90, 0.95, 0.99]:
                r = s1[(s1.forecaster == fc) & (s1.lead == 1) & (s1.method == m)
                       & (s1.threshold_source == src) & ((s1["quantile"] - q).abs() < 1e-9)]
                assert len(r) == 1
                v = r.peak_coverage.iloc[0]
                cells.append(f1(v))
                put(f"S1.{fc}.{src}.Q{int(q * 100)}.{m}", v)
            rows.append((FC_LABEL[fc] if i == 0 else "", m, *cells))
        if fc != FCS[-1]:
            rows.append("\\midrule")
    write(f"tab_S1_threshold_{src}", "Fc. & Method & Q90 & Q95 & Q99", rows, "llccc",
          f"lead 1, peak coverage (%), thresholds from {src} period")

# S2: calibration window, lead 1
s2 = S["S2_calibration_window"]
rows = []
for fc in FCS:
    for i, m in enumerate(["CQR", "Mondrian CQR"]):
        cells = []
        for y in [2, 5, 10]:
            r = s2[(s2.forecaster == fc) & (s2.lead == 1) & (s2.method == m) & (s2.years == y)].iloc[0]
            cells += [f1(r.coverage), f2(r.winkler)]
            put(f"S2.{fc}.{m}.y{y}.cov", r.coverage)
            put(f"S2.{fc}.{m}.y{y}.winkler", r.winkler, "{:.2f}")
        rows.append((FC_LABEL[fc] if i == 0 else "", m, *cells))
    if fc != FCS[-1]:
        rows.append("\\midrule")
hdr = ("& & \\multicolumn{2}{c}{2 years} & \\multicolumn{2}{c}{5 years} & \\multicolumn{2}{c}{10 years} \\\\\n"
       "\\cmidrule(lr){3-4}\\cmidrule(lr){5-6}\\cmidrule(lr){7-8}\n"
       "Fc. & Method & Cov. & Wink. & Cov. & Wink. & Cov. & Wink.")
write("tab_S2_calwindow", hdr, rows, "llcccccc", "lead 1")

# S3: season, lead 1
s3 = S["S3_season"]
SEAS = ["DJF", "MAM", "JJA", "SON"]
rows = []
for fc in FCS:
    for i, m in enumerate(SM):
        cells = []
        vals = []
        for se in SEAS:
            v = s3[(s3.forecaster == fc) & (s3.lead == 1) & (s3.method == m) & (s3.season == se)].coverage.iloc[0]
            vals.append(v)
            cells.append(f1(v))
            put(f"S3.{fc}.{m}.{se}", v)
        rng = max(vals) - min(vals)
        put(f"S3.{fc}.{m}.range", rng)
        rows.append((FC_LABEL[fc] if i == 0 else "", m, *cells, f1(rng)))
    if fc != FCS[-1]:
        rows.append("\\midrule")
write("tab_S3_season", "Fc. & Method & DJF & MAM & JJA & SON & Range", rows, "llccccc",
      "lead 1 coverage (%) by season")

# S4: autocorrelation
s4 = S["S4_autocorrelation"]
rows = []
prev = None
for _, r in s4.sort_values(["forecaster", "lead"]).iterrows():
    if prev is not None and r.forecaster != prev:
        rows.append("\\midrule")
    rows.append((FC_LABEL[r.forecaster] if r.forecaster != prev else "", str(r.lead), f2(r.ac1_median),
                 f"{f2(r.ac1_q25)}--{f2(r.ac1_q75)}",
                 f"{r.spearman_ac1_vs_abs_dev:+.2f} {ci(r.ci)}",
                 f"{r.spearman_ac1_vs_signed_dev:+.2f}"))
    k = f"S4.{r.forecaster}.L{r.lead}"
    put(k + ".ac1", r.ac1_median, "{:.2f}")
    put(k + ".rhoabs", r.spearman_ac1_vs_abs_dev, "{:+.2f}")
    put(k + ".rhoabs.ci", ci(r.ci))
    put(k + ".rhosigned", r.spearman_ac1_vs_signed_dev, "{:+.2f}")
    prev = r.forecaster
write("tab_S4_autocorr",
      "Fc. & Lead & Median lag-1 AC & IQR & $\\rho$(AC, $|$cov.\\ error$|$) [95\\% CI] & $\\rho$(AC, signed error)",
      rows, "ccccccc"[:6])

# S5: hydroclimate terciles, lead 1
s5 = S["S5_hydroclimate"]
rows = []
for fc in FCS:
    first = True
    for var, vlab in [("aridity", "Aridity"), ("frac_snow", "Snow fraction")]:
        for t in ["low", "mid", "high"]:
            cells = []
            for m in ["CQR", "Mondrian CQR"]:
                r = s5[(s5.forecaster == fc) & (s5.lead == 1) & (s5.method == m)
                       & (s5.variable == var) & (s5.tercile == t)].iloc[0]
                cells += [f1(r.coverage), f1(r.peak)]
                put(f"S5.{fc}.{var}.{t}.{m}.cov", r.coverage)
                put(f"S5.{fc}.{var}.{t}.{m}.peak", r.peak)
            rows.append((FC_LABEL[fc] if first else "", vlab if t == "low" else "", t, *cells))
            first = False
    if fc != FCS[-1]:
        rows.append("\\midrule")
hdr = ("& & & \\multicolumn{2}{c}{CQR} & \\multicolumn{2}{c}{Mondrian CQR} \\\\\n"
       "\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n"
       "Fc. & Attribute & Tercile & Cov. & Peak & Cov. & Peak")
write("tab_S5_hydroclimate", hdr, rows, "lllcccc", "lead 1")

# ---------------------------------------------------------------- derived quantities used in the text
# peak coverage of quantile-based conformal methods relative to split conformal
QB = ["CQR", "Mondrian CQR", "ACI (causal, per-basin)"]
_split = MAIN[MAIN.method == "Split conformal"].set_index(["forecaster", "lead"]).peak
_ratio = pd.concat([MAIN[MAIN.method == q].set_index(["forecaster", "lead"]).peak / _split for q in QB])
put("peakratio.quantile_vs_split.min", _ratio.min())
put("peakratio.quantile_vs_split.max", _ratio.max())
for fc in FCS:
    for lead in LEADS:
        d = MAIN[(MAIN.forecaster == fc) & (MAIN.lead == lead)].set_index("method")
        conf = d.loc[list(CONFORMAL)]
        put(f"{fc}.L{lead}.bestwinkler.method", conf.winkler.idxmin())
        put(f"{fc}.L{lead}.conf.covmin", conf.coverage.min())
        put(f"{fc}.L{lead}.conf.covmax", conf.coverage.max())

# ---------------------------------------------------------------- facts from the training runs (notebooks 01-03)
TS = json.loads((RES / "training_summary.json").read_text())
for fc in FCS:
    t = TS[fc]
    put(f"{fc}.params", f"{t['parameters']:,}")
    put(f"{fc}.ntrain", f"{t['train_samples_all_leads']:,}")
    put(f"{fc}.ncal", f"{t['calibration_samples_per_lead']:,}"); put(f"{fc}.ntest", f"{t['test_samples_per_lead']:,}")
    for L, w in t["raw_band_mean_width_by_lead"].items():
        put(f"{fc}.L{L}.rawwidth", w, "{:.2f}")
    cr = list(t["quantile_crossing_pct_by_lead"].values())
    assert len(cr) == 3
    put(f"{fc}.crossing.min", min(cr), "{:.3f}"); put(f"{fc}.crossing.max", max(cr), "{:.3f}")
    assert t["epochs_completed"] == t["epochs_planned"], f"{fc}: training did not complete all epochs"
    put(f"{fc}.epochs", str(t["epochs_planned"]))
    if fc != "v6":
        put(f"{fc}.nattr", str(t["static_attributes"]))
        put(f"{fc}.nattrbasins", str(t["basins_with_attribute_record"]))
# basin counts: CAMELS time-series release, exclusions, attribute coverage
_tot = {TS[fc]["basins_in_release"] for fc in FCS}
assert len(_tot) == 1, _tot
put("basins.release", str(_tot.pop()))
put("basins.used", str(TS["v6"]["basins_used"]))
assert int(NUM["basins.release"]) - len(TS["v6"]["basins_excluded"]) == int(NUM["basins.used"]) == 672
put("basins.excluded", " and ".join(TS["v6"]["basins_excluded"]))
put("attr.gauges", str(TS["v8"]["gauges_in_attribute_files"])); put("attr.n", str(TS["v8"]["static_attributes"]))
put("attr.matched", str(TS["v8"]["basins_with_attribute_record"]))
put("attr.zerofilled", " and ".join(TS["v8"]["basins_without_attribute_record"]))
put("calendargap.pct", TS["v8"]["pct_samples_target_not_L_calendar_days_after_issue"], "{:.1f}")
for fc in FCS:
    assert NUM[f"{fc}.ncal"] == NUM["v6.ncal"] and NUM[f"{fc}.ntest"] == NUM["v6.ntest"]

# overall ranges quoted in the text
_conf = MAIN[MAIN.method.isin(list(CONFORMAL))]
put("all.conf.covmin", _conf.coverage.min()); put("all.conf.covmax", _conf.coverage.max())
_raw = MAIN[MAIN.method == "Raw band"]
put("all.raw.covmin", _raw.coverage.min(), "{:.0f}"); put("all.raw.covmax", _raw.coverage.max(), "{:.0f}")
for fc in FCS:
    r = _raw[_raw.forecaster == fc]
    put(f"{fc}.raw.covmin", r.coverage.min()); put(f"{fc}.raw.covmax", r.coverage.max())
_g = pd.concat([pd.Series([J[fc]["B4_bootstrap_cis"][f"mondrian_minus_cqr_peak_lead{L}"]["delta"]
                           for L in LEADS]) for fc in ["v6", "v7"]])
put("weak.mondriangain.min", _g.min()); put("weak.mondriangain.max", _g.max())
_g8 = pd.Series([J["v8"]["B4_bootstrap_cis"][f"mondrian_minus_cqr_peak_lead{L}"]["delta"] for L in LEADS])
put("v8.mondriangain.min", _g8.min()); put("v8.mondriangain.max", _g8.max())
_fx = ACI[(ACI.method == "ACI") & ((ACI.gamma - 0.005).abs() < 1e-9)]
put("aci_fixed.maxwidth.min", _fx.width_max.min(), "{:.0f}"); put("aci_fixed.maxwidth.max", _fx.width_max.max(), "{:.0f}")
put("aci_fixed.maxovermean.min", (_fx.width_max / _fx.width_mean).min(), "{:.0f}")
_s3 = S["S3_season"]; _s3 = _s3[_s3.lead == 1]
_rng = _s3.groupby(["forecaster", "method"]).coverage.agg(lambda v: v.max() - v.min())
put("S3.range.max", _rng.max())
put("S3.range.mondrian.max", _rng.xs("Mondrian CQR", level="method").max())

# further ranges quoted in the text
put("aci_fixed.cov.min", _fx.coverage.min()); put("aci_fixed.cov.max", _fx.coverage.max())
_ru = ACI[ACI.method == RULE]
put("aci_rule.cov.min", _ru.coverage.min()); put("aci_rule.cov.max", _ru.coverage.max())
put("mondrian.maxwidth.max", ACI[ACI.method == "Mondrian CQR"].width_max.max(), "{:.0f}")
_s1 = S["S1_peak_threshold"]; _s1 = _s1[_s1.lead == 1]
_p = _s1.pivot_table(index=["forecaster", "method", "quantile"], columns="threshold_source", values="peak_coverage")
put("S1.calib_vs_test.maxabsdiff", (_p["calibration"] - _p["test"]).abs().max())
_s2 = S["S2_calibration_window"]; _s2 = _s2[_s2.lead == 1]
_q = _s2.pivot_table(index=["forecaster", "method"], columns="years", values="coverage")
put("S2.maxdrop.y2", (_q[10] - _q[2]).max())
_closest10 = ((_q.sub(90).abs()).idxmin(axis=1) == 10)
put("S2.n10closest", str(int(_closest10.sum()))); put("S2.ncases", str(len(_closest10)))
_s5 = S["S5_hydroclimate"]; _s5 = _s5[(_s5.lead == 1) & (_s5.variable == "aridity") & (_s5.method == "CQR")]
put("S5.aridity.cqr.range.max", _s5.groupby("forecaster").coverage.agg(lambda v: v.max() - v.min()).max())

# ACI step-size grid: values for the text
for _, r in ACI[ACI.method == "ACI"].iterrows():
    k = f"{r.forecaster}.L{r.lead}.aci_g{r.gamma:g}"
    put(k + ".width_max", r.width_max, "{:.1f}"); put(k + ".winkler", r.winkler, "{:.2f}")
    put(k + ".coverage", r.coverage)
_g1 = ACI[(ACI.method == "ACI") & ((ACI.gamma - 0.001).abs() < 1e-12)].set_index(["forecaster", "lead"])
_rl = ACI[ACI.method == RULE].set_index(["forecaster", "lead"])
put("aci_rule_vs_g001.maxabsdiff.winkler", (_g1.winkler - _rl.winkler).abs().max(), "{:.2f}")
_dw = (_g1.winkler - _rl.winkler)
put("aci_rule_vs_g001.maxabsdiff.winkler.L37", _dw[_dw.index.get_level_values("lead") > 1].abs().max(), "{:.2f}")
_d1 = _dw.xs(1, level="lead")[["v6", "v7"]]
put("aci_g001_minus_rule.L1.weak.min", _d1.min(), "{:.2f}"); put("aci_g001_minus_rule.L1.weak.max", _d1.max(), "{:.2f}")
put("aci_g001.cov.min", _g1.coverage.min()); put("aci_g001.cov.max", _g1.coverage.max())
# 7-day mean width of the smaller step sizes (0.001 and 0.005/L) relative to the fixed 0.005
_f5 = ACI[(ACI.method == "ACI") & ((ACI.gamma - 0.005).abs() < 1e-12) & (ACI.lead == 7)].set_index("forecaster").width_mean
_sm = pd.concat([_g1.xs(7, level="lead").width_mean, _rl.xs(7, level="lead").width_mean])
_rt = 100 * _sm / _f5.reindex(_sm.index).values
put("aci.L7.smallstep.widthpct.min", _rt.min(), "{:.0f}"); put("aci.L7.smallstep.widthpct.max", _rt.max(), "{:.0f}")
put("aci_fixed.maxovermean.floor10", str(int((_fx.width_max / _fx.width_mean).min() // 10 * 10)))
put("aci_fixed.pctfloor.max", _fx.pct_alpha_at_floor.max(), "{:.2f}")
# S1 at all lead times
_s1a = S["S1_peak_threshold"]
_pa = _s1a.pivot_table(index=["forecaster", "lead", "method", "quantile"], columns="threshold_source",
                       values="peak_coverage")
_d = (_pa["calibration"].round(1) - _pa["test"].round(1)).abs()
put("S1.calib_vs_test.maxabsdiff.L1", _d.xs(1, level="lead").max())
put("S1.calib_vs_test.maxabsdiff.all", _d.max())
# S4: number of CIs for rho(|dev|) that exclude zero
_s4 = S["S4_autocorrelation"]
_ex = _s4.ci.apply(lambda c: (c[0] > 0) or (c[1] < 0))
put("S4.nci_exclude0", str(int(_ex.sum()))); put("S4.ncases", str(len(_s4)))
# S5: aridity spread at every lead for F3
_s5a = S["S5_hydroclimate"]
for L in LEADS:
    _x = _s5a[(_s5a.lead == L) & (_s5a.variable == "aridity") & (_s5a.method == "CQR")]
    put(f"S5.aridity.cqr.range.L{L}.max", _x.groupby("forecaster").coverage.agg(lambda v: v.max() - v.min()).max())
# S3 at 7 days
_s37 = S["S3_season"]; _s37 = _s37[_s37.lead == 7]
_r7 = _s37.groupby(["forecaster", "method"]).coverage.agg(lambda v: v.max() - v.min())
put("S3.L7.range.max", _r7.max()); put("S3.L7.range.mondrian.max", _r7.xs("Mondrian CQR", level="method").max())
_dev = (S["S3_season"].coverage - 90).abs()
put("S3.maxdev.L1", _dev[S["S3_season"].lead == 1].max())
# Mondrian cut-point sensitivity (B5)
rows = []
cutlab = {"[0.5, 0.9]": "50/90", "[0.7, 0.9]": "70/90", "[0.8, 0.95]": "80/95", "[0.5, 0.8, 0.95]": "50/80/95"}
_allpk = []
for fc in FCS:
    b5 = pd.DataFrame(J[fc]["B5_mondrian_sensitivity"])
    for i, (c, lab) in enumerate(cutlab.items()):
        cells = []
        for L in LEADS:
            r = b5[(b5.lead == L) & (b5.cuts == c)].iloc[0]
            cells += [f"{r.coverage:.1f}", f"{r.peak:.1f}", f"{r.width:.2f}"]
        rows.append((FC_LABEL[fc] if i == 0 else "", lab, *cells))
    for L in LEADS:
        _b = b5[b5.lead == L]
        _allpk.append(_b.peak.max() - _b.peak.min())
    if fc != FCS[-1]:
        rows.append("\\midrule")
put("B5.peak.spread.max", max(_allpk))
hdr = ("& & \\multicolumn{3}{c}{1 d} & \\multicolumn{3}{c}{3 d} & \\multicolumn{3}{c}{7 d} \\\\\n"
       "\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\\cmidrule(lr){9-11}\n"
       "Fc. & Cut points & Cov. & Peak & Width & Cov. & Peak & Width & Cov. & Peak & Width")
write("tab_mondrian_cuts", hdr, rows, "ll" + "ccc" * 3, "source B5_mondrian_sensitivity")

# ---------------------------------------------------------------- extra figures (extra_figures.json)
# reliability curves, per-basin coverage and coverage by water year; notebook 07
import numpy as np
EX = json.loads((RES / "extra_figures.json").read_text())
REL = pd.DataFrame(EX["reliability"]); WY = pd.DataFrame(EX["water_year"])
REL["dev"] = REL.coverage - 100 * REL.nominal
# integrity: 90 % level reproduces the main table, per-basin values reproduce B6, yearly values reproduce B6_drift
_m = MAIN.assign(method=MAIN.method.str.replace("MC-dropout", "MC dropout"))
_r9 = REL[(REL.nominal - 0.9).abs() < 1e-9].merge(_m, on=["forecaster", "lead", "method"], suffixes=("", "_m"))
assert len(_r9) == 36 and (_r9.coverage - _r9.coverage_m).abs().max() < 1e-6, "reliability vs main table"
for fc in FCS:
    for mode in ["pooled", "per_basin"]:
        v = np.array(EX["per_basin"][fc][mode]); g = J[fc]["B6_granularity"][mode]
        assert len(v) == 672
        assert abs(np.median(v) - g["basin_median"]) < 1e-6, (fc, mode, "median")
        assert abs(np.mean(np.abs(v - TARGET) <= 2) - g["frac_within_2pts"]) < 1e-9, (fc, mode, "within2")
    for meth, d in J[fc]["B6_drift"].items():
        w = WY[(WY.forecaster == fc) & (WY.method == meth)].sort_values("water_year")
        assert len(w) == 9 and abs(np.polyfit(w.water_year, w.coverage, 1)[0] - d["slope"]) < 1e-6, (fc, meth, "drift")
print("extra-figure integrity checks passed")
# reliability
_cf = REL[REL.method.isin(["CQR", "Mondrian CQR"])]
put("rel.split.absdev.max", REL[REL.method == "Split conformal"].dev.abs().max())
for fc in FCS:
    put(f"rel.cqr.short.max.{fc}", -_cf[_cf.forecaster == fc].dev.min())
put("rel.cqr.short.max.hi", -_cf[_cf.nominal >= 0.94 - 1e-9].dev.min())
_ga = REL[REL.method.isin(["Gaussian", "MC dropout + aleatoric"])]
put("rel.gauss.cov60.min", _ga[(_ga.nominal - 0.6).abs() < 1e-9].coverage.min())
put("rel.gauss.cov60.max", _ga[(_ga.nominal - 0.6).abs() < 1e-9].coverage.max())
_gp = REL[REL.method == "Gaussian"].set_index(["forecaster", "lead", "nominal"]).coverage
_mp = REL[REL.method == "MC dropout + aleatoric"].set_index(["forecaster", "lead", "nominal"]).coverage
put("rel.gauss_vs_mcal.maxabsdiff", (_gp - _mp).abs().max())
_ep = REL[REL.method == "MC dropout (epistemic)"]
put("rel.epi.cov.max", _ep.coverage.max())
_r = _ep.loc[_ep.coverage.idxmax()]   # the text names where the maximum occurs
assert (_r.forecaster, _r.lead, round(_r.nominal, 2)) == ("v8", 1, 0.98), _r
put("rel.epi.cov98.weak.max", _ep[((_ep.nominal - 0.98).abs() < 1e-9) & _ep.forecaster.isin(["v6", "v7"])].coverage.max())
# per-basin coverage
for fc in FCS:
    for mode in ["pooled", "per_basin"]:
        v = np.array(EX["per_basin"][fc][mode])
        put(f"{fc}.basin.{mode}.below80", str(int((v < 80).sum())))
        put(f"{fc}.basin.{mode}.below50", str(int((v < 50).sum())))
        put(f"{fc}.basin.{mode}.within5", 100 * np.mean(np.abs(v - TARGET) <= 5), "{:.0f}")
        put(f"{fc}.basin.{mode}.min", v.min())
assert all((np.array(EX["per_basin"][fc]["per_basin"]) < 50).sum() == 0 for fc in FCS)   # caption says "none"
_mn = {fc: min(EX["per_basin"][fc]["pooled"]) for fc in FCS}
assert min(_mn, key=_mn.get) == "v7"   # text names F2 as the lowest basin
# coverage by water year
_wr = WY.groupby(["forecaster", "method"]).coverage.agg(lambda v: v.max() - v.min())
put("wy.range.split.max", _wr.xs("Split conformal", level="method").max())
put("wy.range.split.min", _wr.xs("Split conformal", level="method").min())
put("wy.range.cqrfam.max", _wr.drop("Split conformal", level="method").max())
put("wy.range.cqrfam.min", _wr.drop("Split conformal", level="method").min())
for fc in FCS:   # split conformal has the largest yearly range within every forecaster
    assert _wr[fc].idxmax() == "Split conformal", fc
put("wy.cov.min", WY.coverage.min()); put("wy.cov.max", WY.coverage.max())
_top = WY[WY.method == "Split conformal"].loc[lambda d: d.groupby("forecaster").coverage.idxmax()]
assert _top.water_year.nunique() == 1
put("wy.split.peakyear", str(int(_top.water_year.iloc[0])))
put("wy.split.peakyear.min", _top.coverage.min()); put("wy.split.peakyear.max", _top.coverage.max())

# ---------------------------------------------------------------- write numbers.tex
lines = ["% generated by make_tables.py -- do not edit",
         "\\makeatletter",
         "\\newcommand{\\rv}[1]{\\ifcsname res@#1\\endcsname\\csname res@#1\\endcsname"
         "\\else\\errmessage{Unknown result key: #1}\\fi}"]
for k, v in NUM.items():
    tex = MINUS.sub(r"\\ensuremath{-}", v.replace("%", "\\%"))
    lines.append(f"\\expandafter\\def\\csname res@{k}\\endcsname{{{tex}}}")
lines.append("\\makeatother")
(OUT / "numbers.tex").write_text("\n".join(lines) + "\n")
pd.Series(NUM, name="value").rename_axis("key").to_csv(OUT / "numbers.csv")

print(f"wrote {len(list(OUT.glob('tab_*.tex')))} tables and {len(NUM)} numbers to {OUT}/")
