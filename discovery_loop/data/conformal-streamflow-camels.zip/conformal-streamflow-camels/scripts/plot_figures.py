#!/usr/bin/env python3
"""Draw the data figures of the paper as 600-dpi PNG files from the result files.

Usage:  python scripts/plot_figures.py [RESULTS_DIR] [OUT_DIR]
        defaults: results  outputs/figures

Figures:
    fig_skill.png           NSE of F1-F3 at lead 1; F3 against persistence          (notebooks 03, 08)
    fig_coverage.png        coverage on all days and on peak days                    (notebook 04)
    fig_mondrian_gain.png   Mondrian CQR minus CQR on peak days, with 95% CIs        (notebook 04)
    fig_aci_stepsize.png    ACI interval width against the step size                 (notebook 05)
    fig_season.png          coverage by season                                       (notebook 06)
    fig_reliability.png     empirical against nominal coverage, 60-98%               (notebook 07)
    fig_basin_coverage.png  per-basin coverage, pooled and per-basin calibration     (notebook 07)
    fig_wateryear.png       coverage by test water year                              (notebook 07)
"""
import os, sys, glob, json, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

INPUT = sys.argv[1] if len(sys.argv) > 1 else "results"
WORK = sys.argv[2] if len(sys.argv) > 2 else "outputs/figures"
os.makedirs(WORK, exist_ok=True)

def find(name):
    hits = sorted(glob.glob(f"{INPUT}/**/{name}", recursive=True))
    return hits[0] if hits else None

need = ["main_table_all_forecasters.csv", "aci_diagnostics.csv", "sensitivity_results.json", "skill_v8.csv",
        "v6_revision_v2_results.json", "v7_revision_v2_results.json", "v8_revision_v2_results.json",
        "extra_figures.json", "nse_per_basin_all.csv"]
paths = {n: find(n) for n in need}
missing = [n for n, p in paths.items() if p is None]
assert not missing, f"result files not found: {missing}"
for n, p in paths.items(): print(f"  {n}: {p}")

FCS, LEADS = ["v6", "v7", "v8"], [1, 3, 7]
FL = {"v6": "F1", "v7": "F2", "v8": "F3"}
J = {fc: json.load(open(paths[f"{fc}_revision_v2_results.json"])) for fc in FCS}
MAIN = pd.read_csv(paths["main_table_all_forecasters.csv"])
ACI = pd.read_csv(paths["aci_diagnostics.csv"])
SK = pd.read_csv(paths["skill_v8.csv"]).set_index("lead")
SENS = {k: pd.DataFrame(v) for k, v in json.load(open(paths["sensitivity_results.json"])).items()}
EXTRA = json.load(open(paths["extra_figures.json"]))

# point skill on one common set of basins (all basins with a defined NSE; notebook 08)
_N = pd.read_csv(paths["nse_per_basin_all.csv"])
for fc in FCS:
    d = _N[(_N.forecaster == fc) & (_N.lead == 1)].nse_model.dropna()
    J[fc]["B7_nse"] = dict(median=d.median(), q25=d.quantile(.25), q75=d.quantile(.75), frac_above_0p5=(d > 0.5).mean())
_r = []
for L in LEADS:
    d = _N[(_N.forecaster == "v8") & (_N.lead == L)].dropna(subset=["nse_model"])
    _r.append(dict(lead=L, nse_model_median=d.nse_model.median(), nse_persist_median=d.nse_persist.dropna().median(),
                   pct_basins_model_beats_persist=100 * (d.nse_model > d.nse_persist).mean()))
SK = pd.DataFrame(_r).set_index("lead")
RULE = "ACI delay-scaled (gamma=0.005/L)"

# integrity: the main table and the per-forecaster JSON files must agree
for fc in FCS:
    b1 = pd.DataFrame(J[fc]["B1_main"])
    m = MAIN[MAIN.forecaster == fc].merge(b1, on=["lead", "method"], suffixes=("", "_j"))
    assert len(m) == 24 and (m.coverage - m.coverage_j).abs().max() < 1e-6, fc
print("result files consistent")

# style: validated colour-blind-safe palette in fixed order; markers and legends carry identity too
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, INK2, GRID, GREY = "#0b0b0b", "#52514e", "#e4e3df", "#9a9893"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
    "lines.linewidth": 1.6, "savefig.dpi": 600, "savefig.bbox": "tight"})
SAVED = []

def save(fig, name):
    fig.savefig(f"{WORK}/{name}", facecolor="white"); plt.close(fig); SAVED.append(name)
    print("wrote", name)

def panel_title(ax, j, fc):
    ax.set_title(f"({'abc'[j]}) {FL[fc]}", loc="left")


# ---- forecaster skill
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7), gridspec_kw={"width_ratios": [1, 1.5]})
ax = axs[0]
for i, fc in enumerate(FCS):
    n = J[fc]["B7_nse"]
    ax.errorbar(i, n["median"], yerr=[[n["median"] - n["q25"]], [n["q75"] - n["median"]]],
                fmt="osD"[i], color=C[i], ms=7, capsize=3, lw=1.4)
    ax.text(i + 0.12, n["median"], f"{n['median']:.2f}", va="center", fontsize=7.5, color=INK)
ax.set_xticks(range(3)); ax.set_xticklabels([FL[f] for f in FCS]); ax.set_xlim(-0.5, 2.6)
ax.set_ylabel("NSE, lead 1 d (median, IQR)"); ax.set_ylim(-0.05, 1.0)
ax.set_title("(a) Skill of the three forecasters", loc="left")
ax = axs[1]; x = np.arange(len(LEADS)); wd = 0.34
for k, (col, lab, c) in enumerate([("nse_model_median", "F3", C[2]), ("nse_persist_median", "Persistence", GREY)]):
    ax.bar(x + (k - 0.5) * wd, SK.loc[LEADS, col].values, wd * 0.94, color=c, label=lab)
ax.axhline(0, color=INK2, lw=0.8)
for i, L in enumerate(LEADS):
    ax.text(i, 0.72, f"F3 better in\n{SK.loc[L, 'pct_basins_model_beats_persist']:.0f}% of basins",
            ha="center", fontsize=7, color=INK2)
ax.set_xticks(x); ax.set_xticklabels([f"{L} d" for L in LEADS]); ax.set_xlabel("lead time")
ax.set_ylabel("median NSE across basins"); ax.set_ylim(-0.6, 0.9); ax.legend(frameon=False, loc="lower left")
ax.set_title("(b) F3 against persistence", loc="left")
fig.tight_layout(); save(fig, "fig_skill.png")

# ---- coverage on all days and on peak days
METH = ["Raw band", "Split conformal", "CQR", "Mondrian CQR", "ACI (causal, per-basin)"]
MLAB = ["Raw band", "Split", "CQR", "Mondrian", "ACI"]
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.4), sharey="row")
for j, fc in enumerate(FCS):
    for r, (metric, ylab) in enumerate([("coverage", "coverage, all days (%)"), ("peak", "coverage, peak days (%)")]):
        ax = axs[r, j]
        for k, L in enumerate(LEADS):
            d = MAIN[(MAIN.forecaster == fc) & (MAIN.lead == L)].set_index("method").loc[METH]
            xpos = np.arange(len(METH)) + (k - 1) * 0.22
            if metric == "coverage":      # dots: a truncated axis must not use bars
                ax.plot(xpos, d[metric].values, "osD"[k], color=C[k], ms=4.5, ls="none",
                        label=f"{L} d" if (r == 0 and j == 0) else None)
            else:
                ax.bar(xpos, d[metric].values, 0.21, color=C[k])
        if metric == "coverage":
            ax.axhline(90, color=INK, lw=0.9, ls="--"); ax.set_ylim(70, 100)
        else:
            ax.set_ylim(0, 80)
        ax.set_xticks(range(len(METH))); ax.set_xticklabels(MLAB, rotation=35, ha="right")
        if j == 0: ax.set_ylabel(ylab)
        if r == 0: panel_title(ax, j, fc)
h, l = axs[0, 0].get_legend_handles_labels()
fig.legend(h, l, title="lead time", ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.04),
           fontsize=7, title_fontsize=7)
fig.tight_layout(rect=(0, 0, 1, 0.96)); save(fig, "fig_coverage.png")

# ---- Mondrian gain on peaks
fig, ax = plt.subplots(figsize=(4.6, 3.0))
for k, L in enumerate(LEADS):
    ys, lo, hi = [], [], []
    for fc in FCS:
        b = J[fc]["B4_bootstrap_cis"][f"mondrian_minus_cqr_peak_lead{L}"]
        ys.append(b["delta"]); lo.append(b["delta"] - b["ci"][0]); hi.append(b["ci"][1] - b["delta"])
    ax.errorbar(np.arange(3) + (k - 1) * 0.2, ys, yerr=[lo, hi], fmt="osD"[k], color=C[k], ms=4, capsize=3,
                elinewidth=1.2,
                label=f"lead {L} d")
ax.axhline(0, color=INK2, lw=0.8)
ax.set_xticks(range(3)); ax.set_xticklabels([f"{FL[f]}\n(NSE {J[f]['B7_nse']['median']:.2f})" for f in FCS])
ax.set_ylabel("Mondrian CQR − CQR,\npeak coverage (points)")
ax.legend(frameon=False, fontsize=7)
fig.tight_layout(); save(fig, "fig_mondrian_gain.png")

# ---- ACI width against step size
fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.4), sharex=True, sharey="row")
for j, fc in enumerate(FCS):
    for r, (col, ylab) in enumerate([("width_mean", "mean interval width"), ("pct_width_gt5", "intervals wider than 5 (%)")]):
        ax = axs[r, j]
        for k, L in enumerate(LEADS):
            g = ACI[(ACI.forecaster == fc) & (ACI.lead == L) & (ACI.method == "ACI")].sort_values("gamma")
            ax.plot(g.gamma, g[col], marker="o", ms=3.5, color=C[k], label=f"{L} d, fixed γ")
            rr = ACI[(ACI.forecaster == fc) & (ACI.lead == L) & (ACI.method == RULE)].iloc[0]
            ax.plot(rr.gamma, rr[col], marker="*", ms=11, color=C[k], mec=INK, mew=0.6, ls="none",
                    label=f"{L} d, γ = 0.005/L")
        ax.set_xscale("log"); ax.set_ylim(bottom=0)
        if j == 0: ax.set_ylabel(ylab)
        if r == 1: ax.set_xlabel("step size γ")
        if r == 0: panel_title(ax, j, fc)
for r, col in enumerate(["width_mean", "pct_width_gt5"]):
    axs[r, 0].set_ylim(0, 1.08 * ACI[ACI.method.str.startswith("ACI")][col].max())
h, l = axs[0, 0].get_legend_handles_labels()
fig.legend(h, l, ncol=3, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.06), fontsize=7)
fig.tight_layout(rect=(0, 0.06, 1, 1)); save(fig, "fig_aci_stepsize.png")

# ---- coverage by season
s3 = SENS["S3_season"]; s3 = s3[s3.lead == 1]
SEAS = ["DJF", "MAM", "JJA", "SON"]
SM = ["Split conformal", "CQR", "Mondrian CQR", "ACI (delay-scaled)"]
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.8), sharey=True)
for j, fc in enumerate(FCS):
    ax = axs[j]
    for k, m in enumerate(SM):
        v = s3[(s3.forecaster == fc) & (s3.method == m)].set_index("season").loc[SEAS, "coverage"]
        ax.plot(range(4), v.values, marker="osD^"[k], ms=4.5, color=C[k],
                label=m.replace(" conformal", "").replace(" (delay-scaled)", " (γ = 0.005/L)"))
    ax.axhline(90, color=INK, lw=0.9, ls="--")
    ax.set_xticks(range(4)); ax.set_xticklabels(SEAS); panel_title(ax, j, fc)
axs[0].set_ylabel("coverage, lead 1 d (%)")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, ncol=4, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.04), fontsize=7)
fig.tight_layout(rect=(0, 0.07, 1, 1)); save(fig, "fig_season.png")

REL = pd.DataFrame(EXTRA["reliability"]); WY = pd.DataFrame(EXTRA["water_year"])
# ---- reliability
STY = [("Split conformal", "Split", dict(color=C[0], marker="o", ms=2.5)),
       ("CQR", "CQR", dict(color=C[1], marker="s", ms=2.5)),
       ("Mondrian CQR", "Mondrian CQR", dict(color=C[2], marker="D", ms=2.5)),
       ("Gaussian", "Gaussian", dict(color=C[3], ls="--")),
       ("MC dropout + aleatoric", "MC dropout + aleatoric", dict(color=INK2, ls=":")),
       ("MC dropout (epistemic)", "MC dropout (epistemic)", dict(color=GREY, ls="-."))]
fig, axs = plt.subplots(2, 3, figsize=(7.2, 5.0), sharex=True, sharey=True)
for r, L in enumerate([1, 7]):
    for j, fc in enumerate(FCS):
        ax = axs[r, j]; ax.plot([60, 98], [60, 98], color=INK, lw=0.8, ls="--")
        for m, lab, sty in STY:
            d = REL[(REL.forecaster == fc) & (REL.lead == L) & (REL.method == m)].sort_values("nominal")
            ax.plot(100 * d.nominal, d.coverage, lw=1.3, label=lab, **sty)
        ax.set_ylim(0, 100)
        if r == 0: panel_title(ax, j, fc)
        if r == 1: ax.set_xlabel("nominal coverage (%)")
        if j == 0: ax.set_ylabel(f"empirical coverage, {L} d (%)")
h, l = axs[0, 0].get_legend_handles_labels()
fig.legend(h, l, ncol=3, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.05), fontsize=7)
fig.tight_layout(rect=(0, 0.07, 1, 1)); save(fig, "fig_reliability.png")

# ---- per-basin coverage: pooled vs per-basin calibration
edges = np.arange(50, 100.001, 2.5)
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
below = {}
for j, fc in enumerate(FCS):
    ax = axs[j]
    for k, (key, lab) in enumerate([("pooled", "pooled calibration"), ("per_basin", "per-basin calibration")]):
        v = np.array(EXTRA["per_basin"][fc][key]); below[(fc, key)] = int((v < 50).sum())
        if k == 0:   # pooled: light filled bars
            ax.hist(np.clip(v, 50, 99.999), bins=edges, color=C[0], alpha=0.35, label=lab, edgecolor="white", lw=0.4)
        else:        # per-basin: outline only, so no blended colour appears where the two overlap
            ax.hist(np.clip(v, 50, 99.999), bins=edges, histtype="step", color=C[1], lw=1.6, label=lab)
    ax.axvline(90, color=INK, lw=0.9, ls="--"); panel_title(ax, j, fc)
    ax.set_xlabel("per-basin coverage, CQR, 1 d (%)")
axs[0].set_ylabel("number of basins"); axs[2].legend(frameon=False, fontsize=7, loc="upper left")
fig.tight_layout(); save(fig, "fig_basin_coverage.png")
print("basins below 50 % coverage (drawn in the first bin):", below)

# ---- coverage per test water year
fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.7), sharey=True)
for j, fc in enumerate(FCS):
    ax = axs[j]
    for k, m in enumerate(["Split conformal", "CQR", "Mondrian CQR"]):
        d = WY[(WY.forecaster == fc) & (WY.method == m)].sort_values("water_year")
        ax.plot(d.water_year, d.coverage, marker="osD"[k], ms=3.5, color=C[k], label=m.replace(" conformal", ""))
    ax.axhline(90, color=INK, lw=0.9, ls="--"); panel_title(ax, j, fc)
    ax.set_xticks([2006, 2008, 2010, 2012, 2014]); ax.set_xlabel("test water year")
axs[0].set_ylabel("coverage, 1 d (%)")
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, ncol=3, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.02), fontsize=7)
fig.tight_layout(rect=(0, 0.08, 1, 1)); save(fig, "fig_wateryear.png")

print(f"{len(SAVED)} figures written to {WORK}")
