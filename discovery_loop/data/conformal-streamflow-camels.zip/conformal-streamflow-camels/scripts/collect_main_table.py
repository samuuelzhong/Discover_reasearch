#!/usr/bin/env python3
"""Combine the main results of the three forecasters into one table.

Reads v6_revision_v2_results.json, v7_revision_v2_results.json and v8_revision_v2_results.json
(notebook 04; v6 = F1, v7 = F2, v8 = F3) and writes main_table_all_forecasters.csv with one row per
forecaster, lead time and interval method.

Usage:  python scripts/collect_main_table.py [RESULTS_DIR]      default: results
"""
import json
import sys
from pathlib import Path

import pandas as pd

RES = Path(sys.argv[1] if len(sys.argv) > 1 else "results")
COLS = ["lead", "method", "coverage", "peak", "width_mean", "width_median", "width_p90", "winkler", "forecaster"]

frames = []
for fc in ["v6", "v7", "v8"]:
    rows = json.loads((RES / f"{fc}_revision_v2_results.json").read_text())["B1_main"]
    frames.append(pd.DataFrame(rows).assign(forecaster=fc))
table = pd.concat(frames, ignore_index=True)[COLS]
assert len(table) == 3 * 3 * 8, len(table)
table.to_csv(RES / "main_table_all_forecasters.csv", index=False)
print(f"wrote {RES / 'main_table_all_forecasters.csv'} ({len(table)} rows)")
