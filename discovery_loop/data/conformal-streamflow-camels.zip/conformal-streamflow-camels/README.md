# Conformal prediction intervals for multi-day LSTM streamflow forecasts

Code and results for the article

> Alsafari, S.; Yafoz, A. *Conformal Prediction Intervals for Multi-Day LSTM Streamflow Forecasts:
> Effects of Forecaster Inputs and Delayed Feedback in 672 CAMELS-US Basins.* Submitted to *Water* (MDPI), 2026.

The study trains three long short-term memory (LSTM) forecasters on 672 basins of the CAMELS-US data set,
freezes them, and applies eight interval methods to the same stored predictions at lead times of 1, 3 and
7 days: split conformal prediction, conformalized quantile regression (CQR), Mondrian CQR, causal per-basin
adaptive conformal inference (ACI), the uncalibrated quantile band, a Gaussian residual interval and two
variants of Monte Carlo dropout. All tables and all numbers quoted in the article are generated from the
result files in `results/` by the scripts in `scripts/`.

## Forecasters

| Paper | Run identifier | Inputs per day | Input window | Static attributes | Hidden units | Parameters |
|---|---|---|---|---|---|---|
| F1 | `v6` | 5 forcing variables | *t*−365 … *t*−1 | none | 128 | 90,511 |
| F2 | `v7` | 5 forcing variables | *t*−365 … *t*−1 | 39 | 256 | 341,263 |
| F3 | `v8` | 5 forcing variables + observed discharge | *t*−364 … *t* | 39 | 256 | 342,287 |

The run identifiers are used in file names (for example `pred_cache_v8.pkl`, `v8_revision_v2_results.json`).
All forecasters share one architecture (basin embedding of size 16, lead-time embedding of size 4, dropout 0.2,
linear output layer for the 0.05, 0.50 and 0.95 quantiles, pinball loss), the same data, periods and random seed
(42), and were trained for 8 epochs with the Adam optimizer (learning rate 10⁻³) without early stopping.

Periods: training 1 Oct 1980 – 30 Sep 1995; calibration 1 Oct 1995 – 30 Sep 2005; test 1 Oct 2005 – 30 Sep 2014.

## Repository structure

```
notebooks/
  01_forecaster_F1.ipynb            data preparation; training and inference of F1
  02_forecaster_F2.ipynb            training and inference of F2
  03_forecaster_F3.ipynb            training and inference of F3; skill against persistence
  04_interval_methods.ipynb         eight interval methods for one forecaster (run for v6, v7 and v8)
  05_aci_step_size.ipynb            ACI: step-size sweep and delay-scaled step size
  06_sensitivity_analyses.ipynb     peak threshold, calibration window, season, autocorrelation, hydroclimate
  07_calibration_curves.ipynb       coverage across nominal levels, per-basin coverage, coverage by water year
  08_point_skill.ipynb              per-basin NSE of F1-F3 and persistence on a common set of basins
scripts/
  collect_main_table.py             combines the main results of the three forecasters
  make_tables.py                    builds all tables and all numbers quoted in the article
  plot_figures.py                   draws the data figures of the article
results/                            result files of the reported runs (see below)
requirements.txt
CITATION.cff
LICENSE
```

## Data

The notebooks use the CAMELS-US data set (Newman et al., 2015; Addor et al., 2017), available from
https://doi.org/10.5065/D6MW2F4D:

* the time series, version 1.2 (`basin_dataset_public_v1p2`, with the folders `basin_mean_forcing/daymet`
  and `usgs_streamflow`);
* the catchment attribute files `camels_clim.txt`, `camels_topo.txt`, `camels_soil.txt`, `camels_vege.txt`
  and `camels_geol.txt`.

Place both under one input directory (default `data/`). Files are located by name with a recursive search,
so the internal folder layout of the downloaded archives can be kept.

## Requirements

Python 3.10 or later with the packages in `requirements.txt`:

```
pip install -r requirements.txt
```

Notebooks 01–03 train neural networks and use a CUDA device when one is available; with a CUDA device,
F2 and F3 are trained with mixed-precision arithmetic. Notebooks 04–08 and the scripts do not use a GPU.

## Reproducing the analysis

All notebooks read their inputs from `INPUT_DIR` (default `data/`) and `OUTPUT_DIR` (default `outputs/`),
and write their results to `OUTPUT_DIR`. Both can be set as environment variables or edited in the first
code cell. Run the notebooks in order:

| Step | Notebook | Main inputs | Main outputs |
|---|---|---|---|
| 1 | 01 | CAMELS-US time series | `basin_arrays.npz`, `pred_cache_v6.pkl` |
| 2 | 02 | `basin_arrays.npz`, attribute files | `pred_cache_v7.pkl` |
| 3 | 03 | `basin_arrays.npz`, attribute files | `pred_cache_v8.pkl`, `skill_v8.csv` |
| 4 | 04, with `FORECASTER` = `v6`, `v7`, `v8` | `basin_arrays.npz`, prediction cache | `<id>_revision_v2_results.json` |
| 5 | 05 | `basin_arrays.npz`, three prediction caches | `aci_diagnostics.csv` |
| 6 | 06 | `basin_arrays.npz`, three prediction caches, `camels_clim.txt` | `sensitivity_results.json` |
| 7 | 07 | `basin_arrays.npz`, three prediction caches | `extra_figures.json` |
| 8 | 08 | `basin_arrays.npz`, three prediction caches | `nse_per_basin_all.csv` |

`basin_arrays.npz` holds the standardized per-basin arrays and dates; each prediction cache holds, for every
lead time, the quantile predictions for the calibration and test periods, the observations, the basin index
and the repeated dropout passes of the median.

Notebooks 05, 07 and 08 check their results against those of notebooks 03 and 04 and stop if they disagree.
If the CAMELS-US files are not found, notebooks 01–03 run on six synthetic basins (demonstration mode); this
mode only tests the code.

Training on a GPU is not bitwise deterministic, so retrained forecasters differ slightly from those of the
reported runs. The outputs of the reported runs are provided as separate files in this record:

| File | Size | Content |
|---|---|---|
| `basin_arrays.npz` | 162 MB | standardized per-basin arrays and dates (notebook 01) |
| `model_ckpt_v6.pt`, `model_ckpt_v7.pt`, `model_ckpt_v8.pt` | 1–4 MB each | trained weights of F1, F2 and F3 |
| `pred_cache_v6.pkl` | 765 MB | stored predictions of F1 |
| `pred_cache_v7.pkl`, `pred_cache_v8.pkl` | 466 MB each | stored predictions of F2 and F3 |

With these files in `OUTPUT_DIR`, notebooks 01–03 skip training (they resume from the stored weights and
predictions) and notebooks 04–08 reproduce the archived results exactly.

## Reproducing the tables and figures from the archived results

No data download is needed for this step:

```
python scripts/collect_main_table.py results
python scripts/make_tables.py results outputs/tables
python scripts/plot_figures.py results outputs/figures
```

`make_tables.py` writes one LaTeX table per table of the article, `numbers.tex` with one macro per number
quoted in the text, and `numbers.csv` with the same values. It asserts the consistency of the result files
with each other (for example, that the combined main table agrees with the per-forecaster files and that the
90% level of the calibration curves reproduces the main table).

## Result files (`results/`)

| File | Produced by | Content |
|---|---|---|
| `v6_revision_v2_results.json`, `v7_…`, `v8_…` | notebook 04 | coverage, peak coverage, width and Winkler score of all methods (`B1_main`); ACI width (`B2_aci_width`); basin-bootstrap confidence intervals (`B4_bootstrap_cis`); Mondrian cut points (`B5_mondrian_sensitivity`); drift and calibration granularity (`B6_drift`, `B6_granularity`); NSE (`B7_nse`) |
| `main_table_all_forecasters.csv` | `collect_main_table.py` | `B1_main` of the three forecasters in one table |
| `aci_diagnostics.csv` | notebook 05 | ACI with fixed and delay-scaled step sizes, CQR and Mondrian CQR |
| `sensitivity_results.json` | notebook 06 | sensitivity analyses S1–S5 |
| `extra_figures.json` | notebook 07 | calibration curves, per-basin coverage, coverage by water year |
| `nse_per_basin_all.csv` | notebook 08 | per-basin NSE of each forecaster and of persistence at each lead time |
| `skill_v8.csv` | notebook 03 | NSE of F3 and of persistence by lead time |
| `training_summary.json` | notebooks 01–03 | quantities printed during training: basin and sample counts, parameters, training loss by epoch, width of the uncalibrated band, quantile crossing, attribute coverage |

Widths and Winkler scores are in units of the training-period standard deviation of discharge in each basin.
Coverage values are percentages.

## Citation

Please cite the article and this repository (see `CITATION.cff`).

## License

Code: MIT License (see `LICENSE`). Result files: Creative Commons Attribution 4.0 International (CC BY 4.0).
The CAMELS-US data are not redistributed here and are subject to the terms of their providers.

## References

Addor, N.; Newman, A.J.; Mizukami, N.; Clark, M.P. The CAMELS data set: catchment attributes and meteorology
for large-sample studies. *Hydrol. Earth Syst. Sci.* **2017**, 21, 5293–5313.

Gibbs, I.; Candès, E. Adaptive conformal inference under distribution shift. In *Advances in Neural Information
Processing Systems 34*; 2021; pp. 1660–1672.

Newman, A.J.; Clark, M.P.; Sampson, K.; Wood, A.; Hay, L.E.; Bock, A.; Viger, R.J.; Blodgett, D.; Brekke, L.;
Arnold, J.R.; et al. Development of a large-sample watershed-scale hydrometeorological data set for the
contiguous USA: data set characteristics and assessment of regional variability in hydrologic model
performance. *Hydrol. Earth Syst. Sci.* **2015**, 19, 209–223.

Romano, Y.; Patterson, E.; Candès, E. Conformalized quantile regression. In *Advances in Neural Information
Processing Systems 32*; 2019; pp. 3543–3553.

## Funding

This research was funded by the Deanship of Scientific Research (DSR) at King Abdulaziz University, Jeddah,
Saudi Arabia, under grant No. IPP: 518-611-2026.

## Contact

Ayman Yafoz (corresponding author), Department of Information Systems, Faculty of Computing and Information
Technology, King Abdulaziz University, Jeddah, Saudi Arabia — ayafoz@kau.edu.sa
